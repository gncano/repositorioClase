package ejercicio3bis;

import java.io.File;

/**
 *
 * @author dam
 */
public class Ejercicio3bis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        File directorio = new File("dir");
        directorio.mkdir();

        //Llamada a los metodos
        estaOculto(directorio);
        cambiarPermisos(directorio);
        capacidadTotal(directorio);

    }
   //Comprobar si el directorio está oculto en el sistema de archivos
    private static void estaOculto(File directorio) {
        boolean oculto = directorio.isHidden();
        System.out.println(oculto ? "El directorio esta oculto" : "El directorio no esta oculto");

    }
  
    //Cambiar los permisos a solo lectura
    private static void cambiarPermisos(File directorio) {
        boolean lectura = directorio.setReadOnly();
        System.out.println(lectura ? "Ahora es de lectura" : "No se ha podido cambiar");
    }

    //Devuelve la capacidad total del disco (en bytes) donde está el directorio.
    private static void capacidadTotal(File directorio) {
        long total = directorio.getTotalSpace();
        System.out.println("Capacidad total: " + total + " bytes");
    }

}
