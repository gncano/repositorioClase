package com.gcs.ej2canogonzalo.data.local.entidades

data class Categoria(
    val codigo: String,
    val denominacion: String
)